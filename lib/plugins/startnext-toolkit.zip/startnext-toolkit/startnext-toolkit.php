<?php
/* 
 * Plugin Name: StartNext Toolkit
 * Author: EnvyTheme Team
 * Author URI: envytheme.com
 * Description: A Light weight and easy toolkit for visula composer addons
 * Version: 1.3.0
 */
if (!defined('ABSPATH')) {
    exit; //Exit if accessed directly
}
//define
define('STARTNEXT_ACC_URL', WP_PLUGIN_URL . '/' . plugin_basename(dirname(__FILE__)) . '/');
define('STARTNEXT_ACC_PATH', plugin_dir_path(__FILE__));

function startnext_toolkit_get_page_as_list()
{
    $args = wp_parse_args(array(
        'post_type' => 'page',
        'numberposts' => -1,
    ));

    $posts = get_posts($args);
    $post_options = array(esc_html__('--Select Page--', 'startnext-toolkit') => '');

    if ($posts) {
        foreach ($posts as $post) {
            $post_options[$post->post_title] = $post->ID;
        }
    }
    return $post_options;
}

function startnext_toolkit_get_page_feature_cat()
{
    $arg = array(
        'taxonomy' => 'feature_cat',
        'orderby' => 'name',
        'order'   => 'ASC'
    );
    $args = get_categories($arg);
    $args_options = array(esc_html__('--Select Category--', 'startnext-toolkit') => '');
    if ($args) {
        foreach ($args as $args) {
            $args_options[$args->name] = $args->term_id;
        }
    }
    return $args_options;
}

//Print short codes in widgets
add_filter('widget_text', 'do_shortcode');

//Custom Post
function startnext_toolkit_custom_post()
{
    //Project Custom Post
    register_post_type('project',
        array(
            'labels' => array(
                'name' => esc_html__('Projects', 'startnext-toolkit'),
                'singular_name' => esc_html__('Project', 'startnext-toolkit'),
            ),
            'menu_icon' => 'dashicons-images-alt',
            'supports' => array('title', 'thumbnail', 'editor', 'excerpt'),
            'public' => true,  
        )
    );
    
    //Features Custom Post
    register_post_type('feature',
        array(
            'labels' => array(
                'name' => esc_html__('Features', 'startnext-toolkit'),
                'singular_name' => esc_html__('Feature', 'startnext-toolkit'),
            ),
            'menu_icon' => 'dashicons-feedback',
            'supports' => array('title', 'editor', 'excerpt'),
            'public' => true,   
            'show_in_rest' => true,  
            'has_archive' => true,         
        )
    );

    //Services Custom Post
    register_post_type('services',
        array(
            'labels' => array(
                'name' => esc_html__('Services', 'startnext-toolkit'),
                'singular_name' => esc_html__('Service', 'startnext-toolkit'),
            ),
            'menu_icon' => 'dashicons-groups',
            'supports' => array('title', 'editor', 'excerpt'),
            'public' => true,   
            'show_in_rest' => true,  
            'has_archive' => true,         
        )
    );


}
add_action('init', 'startnext_toolkit_custom_post');

//Taxonomy Custom Post
function startnext_custom_post_taxonomy(){
    register_taxonomy(
      'project_cat',
      'project',
        array(
          'hierarchical'      => true,
          'label'             => esc_html__('Projects Category', 'startnext-toolkit' ),
          'query_var'         => true,
          'show_admin_column' => true,
              'rewrite'         => array(
              'slug'          => 'project-category',
              'with_front'    => true
              )
        )
      );
    
    register_taxonomy(
        'feature_cat',
        'feature',
            array(
            'hierarchical'      => true,
            'label'             => esc_html__('Feature Category', 'startnext-toolkit' ),
            'query_var'         => true,
            'show_admin_column' => true,
                'rewrite'         => array(
                'slug'          => 'feature-category',
                'with_front'    => true
                )
            )
    );
  }
add_action('init', 'startnext_custom_post_taxonomy');

//Loading VC addons
require_once(STARTNEXT_ACC_PATH . 'vc-addons/vc-blocks-load.php');

//Theme Shortcode
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/section-title-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/banner-one-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/banner-two-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/hosting-banner-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/features-box-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/features-box-slider-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/hosting-service-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/design-and-development-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/our-team-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/fun-facts-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/contact-box-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/pricing-plans-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/user-feedback-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/ready-to-talk-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/partner-logo-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/our-recent-works.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/post-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/domain-search-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/why-choose-us-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/cta-area-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/our-services-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/faq-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/about-us-shortcode.php');
require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/contact-info-cards-shortcode.php');

//Shortcode depended on Visual Composer
include_once(ABSPATH . 'wp-admin/includes/plugin.php');

if (is_plugin_active('js_composer/js_composer.php')) {
    //require_once(CRAZY_ACC_PATH . 'theme-shortcodes/staff-shortcode.php');
}

//Registering crazy toolkit files
function startnext_toolkit_files()
{
    wp_enqueue_style('startnext-toolkit', plugin_dir_url(__FILE__) . 'assets/css/startnext-toolkit.css');
}

add_action('wp_enqueue_scripts', 'startnext_toolkit_files');

if ( ! function_exists( 'startnext_text_domain' ) ) {
	//Loads plugin text domain so it can be used in translation
	function startnext_text_domain() {
		load_plugin_textdomain( 'startnext-toolkit', false, STARTNEXT_ACC_PATH . '/languages' );
	}
	add_action( 'plugins_loaded', 'startnext_text_domain' );
}


add_filter('the_content', 'startnext_remove_empty_p', 20, 1);
function startnext_remove_empty_p($content){
    $content = force_balance_tags($content);
    return preg_replace('#<p>\s*+(<br\s*/*>)?\s*</p>#i', '', $content);
}

add_filter('script_loader_tag', 'startnext_clean_script_tag');
  function startnext_clean_script_tag($input) {
        $input = str_replace( array( 'type="text/javascript"', "type='text/javascript'" ), '', $input );
        return $input;
}

?>