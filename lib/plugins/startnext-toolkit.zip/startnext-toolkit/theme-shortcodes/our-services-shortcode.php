<?php
function startnext_our_services_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'custom_class'  => '',
        'count'         => '',
        'columns'       => 4,
    ), $atts) );

    if ($columns == 1) {
        $column = 'col-lg-12 col-md-6';
    }elseif ($columns == 2) {
        $column = 'col-lg-6 col-md-6';
    }elseif ($columns == 3) {
        $column = 'col-lg-4 col-md-6';
    }elseif ($columns == 4) {
        $column = 'col-lg-3 col-md-6';
    }


    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $domain = 'startnext-toolkit';

    $startnext_our_services_markup ='';
    $startnext_our_services_markup .='
            <div class="row '.esc_attr__($custom_class, $domain).'">';
                $services_array = new WP_Query(
                array('posts_per_page' => $count, 'post_type' => 'services'));
                while($services_array->have_posts()): $services_array->the_post();
                $id = get_the_ID();
                $icon = get_post_meta( get_the_ID(), 'startnext_service_iconselect', true );
                $iconcolor = get_post_meta( get_the_ID(), 'startnext_service_iconcolor', true );
                $iconbg = get_post_meta( get_the_ID(), 'startnext_service_iconbg', true );
                $startnext_our_services_markup .='
            
                <div class="'.esc_attr__($column, $domain).'">
                    <div class="single-services-box">
                        <div class="icon" style="background: '.esc_attr__($iconbg,'startnext-toolkit') .';" >';
                        if (empty($icon)) {
                            $startnext_our_services_markup .='
                            <i class="fa fa-cog" style="color: '.esc_attr__($iconcolor,'startnext-toolkit').';" ></i>';
                        }else{
                            $startnext_our_services_markup .='
                            <i class="'.esc_attr__($icon,'startnext-toolkit') .'" style="color: '.esc_attr__($iconcolor,'startnext-toolkit').';" ></i>';
                        }
                        $startnext_our_services_markup .='
                        </div>
                        <h3><a href="'.get_the_permalink(get_the_ID()).'">'.get_the_title($id) .'</a></h3>
                        <p>'.get_the_excerpt($id) .'</p>
                    </div>
                </div>';
                endwhile;
                $startnext_our_services_markup .='
            </div>';
    return $startnext_our_services_markup;
}
add_shortcode('startnext_our_services', 'startnext_our_services_shortcode');