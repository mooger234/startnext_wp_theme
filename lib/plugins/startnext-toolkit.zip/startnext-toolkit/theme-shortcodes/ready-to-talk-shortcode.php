<?php
function startnext_ready_to_talk_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'heading'         => '',
        'toptext'         => '',
        'linkname'        => '',
        'btnname'         => '',
        'type'     	  	  => 1,
        'link_to_page'    => '',
        'external_link'   => '',
        'type2'     	  => 1,
        'link_to_page2'   => '',
        'external_link2'  => '',
        'custom_class'    => '',
    ), $atts) );

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }

    if($type == 1){
        $link_source = get_page_link($link_to_page); 
    } else {
        $link_source = $external_link;
    }

    if($type2 == 1){
        $link_source2 = get_page_link($link_to_page2); 
    } else {
        $link_source2 = $external_link2;
    }
    $domain = 'startnext-toolkit';

    $startnext_ready_to_talk_markup ='';
    $startnext_ready_to_talk_markup .='
    <div class="startnext'.esc_attr__($custom_class, $domain).'">    
        <h3>'.esc_html__($heading,'startnext-toolkit') .'</h3>
        <p>'.esc_html__($toptext,'startnext-toolkit') .'</p>';
        if (($link_source != '') && ($btnname != '')) {
            $startnext_ready_to_talk_markup .='
            <a href="'.esc_url($link_source).'" class="btn btn-primary">'.esc_html__($btnname,'startnext-toolkit').'</a>';
        }
        $startnext_ready_to_talk_markup .='
        <span>';
        if (($link_source2 != '') && ($linkname != '')) {
            $startnext_ready_to_talk_markup .='
            <a href="'.esc_url($link_source2) .'">'.esc_html__($linkname,'startnext-toolkit') .'</a>';
        }
        $startnext_ready_to_talk_markup .='        
        </span>
    </div>';
    return $startnext_ready_to_talk_markup;
}
add_shortcode('startnext_ready_to_talk', 'startnext_ready_to_talk_shortcode');