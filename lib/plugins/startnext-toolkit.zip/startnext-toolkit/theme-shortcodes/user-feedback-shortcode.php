<?php
function startnext_user_feedback_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'img'          => '',
        'name'         => '',
        'designation'  => '',
        'feedback'     => '',
        'custom_class'  => '',
        'style'        => 1,
    ), $atts) );
    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $domain = 'startnext-toolkit';
    $feedbacks = vc_param_group_parse_atts($atts['group_feedbacks']); 
    $domain = 'startnext-toolkit';
    $startnext_user_feedback_markup ='';
    if($style == 1){
    $startnext_user_feedback_markup .='
        <div class="feedback-slides'.esc_attr__($custom_class, $domain).'">
            <div class="client-feedback">
                <div>';
                foreach($feedbacks as $feedback){
                    if (!empty($feedback)) {
                        if(isset($feedback['img']) &&  isset($feedback['name']) &&  isset($feedback['feedback'])):
                            $image = wp_get_attachment_image_src($feedback['img'], 'full');
                            $startnext_user_feedback_markup .='
                            <div class="item">
                                <div class="single-feedback">
                                    <div class="client-img">
                                        <img src="'.esc_url($image[0]).'" alt="'.esc_attr__($feedback['name'], $domain).'">
                                    </div>

                                    <h3>'.esc_html__($feedback['name'], $domain).'</h3>';
                                    if (isset($feedback['designation'])) {
                                        $startnext_user_feedback_markup .='
                                        <span>'.esc_html__($feedback['designation'], $domain).'</span> ';
                                    }
                                    $startnext_user_feedback_markup .='
                                    <p>'.esc_html__($feedback['feedback'], $domain).'</p>
                                </div>
                            </div>';
                        endif;
                    }
                }
                $startnext_user_feedback_markup .='
                </div>
            </div>

            <div class="client-thumbnails">
                <div>';
                    foreach($feedbacks as $feedback){
                        if (!empty($feedback)) {
                            if(isset($feedback['img']) &&  isset($feedback['name']) &&  isset($feedback['feedback'])):
                                  $image = wp_get_attachment_image_src($feedback['img'], 'full');
                                $startnext_user_feedback_markup .='
                                <div class="item">
                                    <div class="img-fill"> <img src="'.esc_url($image[0]).'" alt="'.esc_attr__($feedback['name'], $domain).'"></div>
                                </div>';
                            endif;
                        }
                    }
                    $startnext_user_feedback_markup .='
                </div>

                <button class="prev-arrow slick-arrow">
                    <i data-feather="arrow-left"></i>
                </button>
                
                <button class="next-arrow slick-arrow">
                    <i data-feather="arrow-right"></i>
                </button>
            </div>
        </div>';
    }else{
        $startnext_user_feedback_markup .='
        <div class="testimonials-slides'.esc_attr__($custom_class, $domain).'">';
            foreach($feedbacks as $feedback){
                if (!empty($feedback)) {
                    if(isset($feedback['img']) &&  isset($feedback['name']) &&  isset($feedback['feedback'])):
                        $image = wp_get_attachment_image_src($feedback['img'], 'full');
                        $startnext_user_feedback_markup .='
                        <div class="single-feedback-item">
                            <div class="client-info align-items-center">
                                <div class="image">
                                    <img src="'.esc_url($image[0]).'" alt="'.esc_attr__($feedback['name'], $domain).'">
                                </div>
    
                                <div class="title">
                                    <h3>'.esc_html__($feedback['name'], $domain).'</h3>';
                                    if (isset($feedback['designation'])) {
                                        $startnext_user_feedback_markup .='
                                        <span>'.esc_html__($feedback['designation'], $domain).'</span> ';
                                    }
                                    $startnext_user_feedback_markup .='
                                </div>
                            </div>
    
                            <p>'.esc_html__($feedback['feedback'], $domain).'</p>
                        </div>';
                    endif;
                }
            } $startnext_user_feedback_markup .='
        </div>'; 
    }
    return $startnext_user_feedback_markup;
}
add_shortcode('startnext_user_feedback', 'startnext_user_feedback_shortcode');