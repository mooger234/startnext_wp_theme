<?php
function startnext_our_recent_works_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'count'         => -1,
        'style'         => 1,
        'custom_class'  => '',
        'columns'       => 1,
    ), $atts) );

    if ($columns == 2) {
        $column = 'col-lg-6 col-md-6';
    }elseif ($columns == 3) {
        $column = 'col-lg-4 col-md-6';
    }elseif ($columns == 4) {
        $column = 'col-lg-3 col-md-6';
    }

    $domain = 'startnext-toolkit';
    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $startnext_our_recent_works_markup ='';

    if ($style == 1) {
    $startnext_our_recent_works_markup .='
    <div class="row m-0'.esc_attr__($custom_class, $domain).'">
        <div class="works-slides">';
            $work_array = new WP_Query(
                array('posts_per_page' => $count, 'post_type' => 'project', 'meta_key' => '_thumbnail_id'));
                while($work_array->have_posts()): $work_array->the_post();
                $icon = get_post_meta( get_the_ID(), 'startnext_iconselect', true );
                $startnext_our_recent_works_markup .='
                <div class="col-lg-12">
                    <div class="single-works">
                    <img src="'.__(get_the_post_thumbnail_url(get_the_ID(), 'project-card-thumb'), 'startnext-toolkit').'" alt="'.esc_attr__('image', 'startnext-toolkit').'">
                        <a href="'.__(get_the_permalink(), 'startnext-toolkit').'" class="icon">';
                        if( !empty( $icon) ) : 
                        $startnext_our_recent_works_markup .='
                        <i class="'.esc_attr__($icon, 'startnext-toolkit').'" ></i>';
                        else:
                        $startnext_our_recent_works_markup .='
                        <i data-feather="settings"></i> ';
                        endif;
                        $startnext_our_recent_works_markup .='
                        </a>
                        <div class="works-content">
                            <h3><a href="'.__(get_the_permalink(), 'startnext-toolkit').'">'.__(get_the_title(), 'startnext-toolkit').'</a></h3>
                            <p>'.__(get_the_excerpt(), 'startnext-toolkit') .'</p>
                        </div>
                    </div>
                </div>';

            endwhile;
            wp_reset_query();
            $startnext_our_recent_works_markup .= ' 
        </div>
    </div>';
    } else{
    $startnext_our_recent_works_markup .= ' 
    <div class="row'.esc_attr__($custom_class, $domain).'">';
        $work_array = new WP_Query(
            array('posts_per_page' => $count, 'post_type' => 'project', 'meta_key' => '_thumbnail_id'));
            while($work_array->have_posts()): $work_array->the_post();
            $icon = get_post_meta( get_the_ID(), 'startnext_iconselect', true );
            $startnext_our_recent_works_markup .='
            <div class="'.esc_attr__($column, $domain).'">
                <div class="single-works">
                    <img src="'.__(get_the_post_thumbnail_url(get_the_ID(), 'project-card-thumb'), 'startnext-toolkit').'" alt="'.esc_attr__('image', 'startnext-toolkit').'">
                    <a href="'.__(get_the_permalink(), 'startnext-toolkit').'" class="icon">';
                    if( !empty( $icon) ) : 
                    $startnext_our_recent_works_markup .='
                    <i class="'.esc_attr__($icon, 'startnext-toolkit').'" ></i>';
                    else:
                    $startnext_our_recent_works_markup .='
                    <i data-feather="settings"></i> ';
                    endif;
                    $startnext_our_recent_works_markup .='
                    </a>
                    <div class="works-content">
                        <h3><a href="'.__(get_the_permalink(), 'startnext-toolkit').'">'.__(get_the_title(), 'startnext-toolkit').'</a></h3>
                        <p>'.__(get_the_excerpt(), 'startnext-toolkit') .'</p>
                    </div>
                </div>
            </div>';
        endwhile;
        wp_reset_query();
        $startnext_our_recent_works_markup .= ' 
    </div>';
    }
    return $startnext_our_recent_works_markup;
}
add_shortcode('startnext_our_recent_works', 'startnext_our_recent_works_shortcode');