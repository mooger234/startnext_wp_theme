<?php
function startnext_about_us_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'img'           => '',
        'custom_class'  => '',
    ), $atts) );

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $items = vc_param_group_parse_atts($atts['group_about_card']); 
    $side_image = wp_get_attachment_image_src($img, 'large');
    $domain = 'startnext-toolkit';

    $startnext_about_us_markup ='';
    $startnext_about_us_markup .='
    <div class="startnext'.esc_attr__($custom_class, $domain).'">    
        <div class="row'.esc_attr__($custom_class, $domain).'">
            <div class="col-lg-6 col-md-12">
                <div class="about-image">
                    <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('image', $domain).'">
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="about-content">
                    <div class="section-title">
                        <h2>'.esc_html__($title, $domain).'</h2>
                        <div class="bar"></div>
                        '.__(wpautop($content), $domain) .'
                </div>
            </div>
        </div>

        <div class="about-inner-area">
            <div class="row">';
                foreach($items as $item){
                    if (!empty($item)) {
                        if(isset($item['title']) &&  isset($item['description']) ):
                            $startnext_about_us_markup .='
                            <div class="col-lg-4 col-md-6">
                                <div class="about-text">
                                    <h3>'.esc_html__($item['title'],'startnext-toolkit').'</h3>
                                    <p>'.esc_html__($item['description'],'startnext-toolkit').'</p>
                                </div>
                            </div>';
                        endif;
                    }
                }
                $startnext_about_us_markup .='
            </div>
        </div>
    </div>
    ';
    return $startnext_about_us_markup;
}
add_shortcode('startnext_about_us', 'startnext_about_us_shortcode');