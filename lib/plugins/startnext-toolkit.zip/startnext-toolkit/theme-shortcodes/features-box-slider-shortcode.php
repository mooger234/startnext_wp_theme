<?php
function startnext_fatures_box_slider_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'description'   => '',
        'icon'          => '',
        'iconcolor'     => '#44ce6f',
        'iconbg'        => '#cdf1d8',
        'custom_class'  => '',
    ), $atts) );
    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $items = vc_param_group_parse_atts($atts['group_features']); 
    $domain = 'startnext-toolkit';

    $startnext_fatures_box_slider_markup ='';
    $startnext_fatures_box_slider_markup .='
    <div class="row'.esc_attr__($custom_class, $domain).'">
        <div class="boxes-slides">';
            foreach($items as $item){
                if (!empty($item)) {
                    if(isset($item['title']) &&  isset($item['description']) ):
                        $startnext_fatures_box_slider_markup .='
                        <div class="col-lg-12 col-md-12">
                        <div class="single-box">
                            <div class="icon" style="background: '.esc_attr__($item['iconbg'],'startnext-toolkit') .';" >';
                            if (empty($item['icon'])) {
                                $startnext_fatures_box_slider_markup .='
                                <i class="fa fa-cog" style="color: '.esc_attr__($item['iconcolor'],'startnext-toolkit') .';" ></i>';
                            }else{
                                $startnext_fatures_box_slider_markup .='
                                <i class="'.esc_attr__($item['icon'],'startnext-toolkit') .'" style="color: '.esc_attr__($item['iconcolor'],'startnext-toolkit') .';" ></i>';
                            }
                            $startnext_fatures_box_slider_markup .='
                            </div>
                            <h3>'.esc_html__($item['title'],'startnext-toolkit') .'</h3>
                            <p>'.esc_html__($item['description'],'startnext-toolkit') .'</p>
                        </div>
                        </div>';
                    endif;
                }
            }
            $startnext_fatures_box_slider_markup .='
        </div>
    </div>
    ';
    return $startnext_fatures_box_slider_markup;
}
add_shortcode('startnext_fatures_box_slider', 'startnext_fatures_box_slider_shortcode');