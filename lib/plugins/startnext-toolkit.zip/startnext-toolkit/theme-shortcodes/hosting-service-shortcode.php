<?php
function startnext_hosting_service_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'description'   => '',
        'img'          => '',
        'custom_class'  => '',
    ), $atts) );
    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $items = vc_param_group_parse_atts($atts['group_items']); 
    $side_image = wp_get_attachment_image_src($img, 'large');
    $domain = 'startnext-toolkit';

    $startnext_hosting_service_markup ='';
    $startnext_hosting_service_markup .='
    <div class="row h-100 justify-content-center align-items-center'.esc_attr__($custom_class, $domain).'">';
        if ($side_image[0] != '') { 
            $startnext_hosting_service_markup .='
            <div class="col-lg-6 col-md-12 services-right-image single-right-image sr-image-top">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/cercle-shape.png" class="bg-image rotateme" alt="'.esc_attr__('shape', 'startnext-toolkit').'">
                <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('hero-img', 'startnext-toolkit').'" class="wow fadeInUp bannerrightimg" >
            </div>
            ';
        }else{
        $startnext_hosting_service_markup .='
            <div class="col-lg-6 col-md-12 services-right-image sr-image-top">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/book-self.png" class="wow fadeInDown" data-wow-delay="0.6s" alt="'.esc_attr__('book-self', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/box.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('box', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/chair.png" class="wow fadeInLeft" data-wow-delay="0.6s" alt="'.esc_attr__('chair', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/cloud.png" class="wow zoomIn" data-wow-delay="0.6s" alt="'.esc_attr__('cloud', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/cup.png" class="wow bounceIn" data-wow-delay="0.6s" alt="'.esc_attr__('cup', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/flower-top.png" class="wow fadeInDown" data-wow-delay="0.6s" alt="'.esc_attr__('flower', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/head-phone.png" class="wow zoomIn" data-wow-delay="0.6s" alt="'.esc_attr__('head-phone', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/monitor.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('monitor', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/mug.png" class="wow rotateIn" data-wow-delay="0.6s" alt="'.esc_attr__('mug', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/table.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('table', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/tissue.png" class="wow zoomIn" data-wow-delay="0.6s" alt="'.esc_attr__('tissue', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/water-bottle.png" class="wow zoomIn" data-wow-delay="0.6s" alt="'.esc_attr__('water-bottle', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/wifi.png" class="wow fadeInLeft" data-wow-delay="0.6s" alt="'.esc_attr__('wifi', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/cercle-shape.png" class="bg-image rotateme" alt="'.esc_attr__('shape', 'startnext-toolkit').'">
                
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/main-pic.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('main-pic', 'startnext-toolkit').'">
            </div>';
        }
        $startnext_hosting_service_markup .='



        <div class="col-lg-6 col-md-12 services-content">
            <div class="section-title">
                <h2>'.esc_html__($title, 'startnext-toolkit').'</h2>
                <div class="bar"></div>
                <p>'.esc_html__($description, 'startnext-toolkit').'</p>
            </div>

            <div class="row">';
                foreach($items as $item){
                    if (!empty($item)) {
                        if(isset($item['item']) &&  isset($item['icon']) ):
                            $startnext_hosting_service_markup .='
                            <div class="col-lg-6 col-md-6">
                                <div class="box">
                                    <i class="'.esc_attr__($item['icon'], 'startnext-toolkit').'" ></i> '.esc_html__($item['item'], 'startnext-toolkit').'
                                </div>
                            </div>';
                        endif;
                    }
                }
                $startnext_hosting_service_markup .='
            </div>
        </div>';

        if ($side_image[0] != '') { 
            $startnext_hosting_service_markup .='
            <div class="col-lg-6 col-md-12 services-right-image single-right-image sr-image-bottom">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/cercle-shape.png" class="bg-image rotateme" alt="'.esc_attr__('shape', 'startnext-toolkit').'">
                <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('hero-img', 'startnext-toolkit').'" class="wow fadeInUp bannerrightimg" >
            </div>
            ';
        }else{
        $startnext_hosting_service_markup .='
            <div class="col-lg-6 col-md-12 services-right-image sr-image-bottom">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/book-self.png" class="wow fadeInDown" data-wow-delay="0.6s" alt="'.esc_attr__('book-self', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/box.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('box', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/chair.png" class="wow fadeInLeft" data-wow-delay="0.6s" alt="'.esc_attr__('chair', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/cloud.png" class="wow zoomIn" data-wow-delay="0.6s" alt="'.esc_attr__('cloud', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/cup.png" class="wow bounceIn" data-wow-delay="0.6s" alt="'.esc_attr__('cup', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/flower-top.png" class="wow fadeInDown" data-wow-delay="0.6s" alt="'.esc_attr__('flower', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/head-phone.png" class="wow zoomIn" data-wow-delay="0.6s" alt="'.esc_attr__('head-phone', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/monitor.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('monitor', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/mug.png" class="wow rotateIn" data-wow-delay="0.6s" alt="'.esc_attr__('mug', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/table.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('table', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/tissue.png" class="wow zoomIn" data-wow-delay="0.6s" alt="'.esc_attr__('tissue', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/water-bottle.png" class="wow zoomIn" data-wow-delay="0.6s" alt="'.esc_attr__('water-bottle', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/wifi.png" class="wow fadeInLeft" data-wow-delay="0.6s" alt="'.esc_attr__('wifi', 'startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/cercle-shape.png" class="bg-image rotateme" alt="'.esc_attr__('shape', 'startnext-toolkit').'">
                
                <img src="'. get_template_directory_uri() .'/assets/img/services-right-image/main-pic.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('main-pic', 'startnext-toolkit').'">
            </div>';
        }
        $startnext_hosting_service_markup .='
    </div>';
    return $startnext_hosting_service_markup;
}
add_shortcode('startnext_hosting_service', 'startnext_hosting_service_shortcode');