<?php
function startnext_cta_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'short_desc'    => '',
        'short_desc'    => '',
        'btnname'       => '',
        'type'     	  	=> 1,
        'link_to_page'  => '',
        'external_link' => '',
        'custom_class'  => '',
    ), $atts) );

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }

    if($type == 1){
        $link_source = get_page_link($link_to_page); 
    } else {
        $link_source = $external_link;
    }

    $domain = 'startnext-toolkit';

    $startnext_cta_markup =' 
    <div class="cta-area ptb-80 '.esc_attr__($custom_class, $domain).'">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-7 col-md-6">
                    <div class="cta-content">
                        <h3>'.esc_html__($title, $domain).'</h3>
                    </div>
                </div>

                <div class="col-lg-5 col-md-6">
                    <div class="cta-right-content">
                        <div class="hosting-price">
                            <span>'.esc_html__($short_desc, $domain).'</span>
                            <h4>'.esc_html__($short_desc, $domain).'</h4>
                        </div>';
                        if(!$btnname == ''){ $startnext_cta_markup .=' 
                            <div class="buy-btn">
                                <a href="'.esc_url($link_source, $domain).'" class="btn btn-primary">'.esc_html__($btnname, $domain).'</a>
                            </div>';
                        } $startnext_cta_markup .=' 
                    </div>
                </div>
            </div>
        </div>
    </div>';

    return $startnext_cta_markup;
    
}
add_shortcode('startnext_cta', 'startnext_cta_shortcode');