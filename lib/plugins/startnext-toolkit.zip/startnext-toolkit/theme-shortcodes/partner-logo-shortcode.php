<?php
function startnext_partner_logo_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'custom_class'  => '',
    ), $atts) );

    $logos = vc_param_group_parse_atts($atts['group_partener_logos']); 
    $domain = 'startnext-toolkit';
    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    
    $startnext_partner_logo_markup ='';
    $startnext_partner_logo_markup .='
    <div class="partner-area partner-section'.esc_attr__($custom_class, $domain).'">
        <div class="container">
            <h5>'.esc_html__($title, $domain).'</h5>
            <div class="partner-inner">
                <div class="row">';
                    foreach($logos as $logo){
                        if (!empty($logo)) {
                            if(isset($logo['graylogo']) &&  isset($logo['mainlogo']) ):
                                $image_gray = wp_get_attachment_image_src($logo['graylogo'], 'full');
                                $image_main = wp_get_attachment_image_src($logo['mainlogo'], 'full');
                                $startnext_partner_logo_markup .='
                                <div class="col-lg-2 col-md-3 col-6">
                                    <a href="'.esc_attr__($logo['link'], $domain).'">
                                        <img src="'.esc_url($image_gray[0]).'" alt="'.esc_attr__('partner', $domain).'">
                                        <img src="'.esc_url($image_main[0]).'" alt="'.esc_attr__('partner', $domain).'">
                                    </a>
                                </div>';
                            endif;
                        }
                    }
                    $startnext_partner_logo_markup .='

                </div>
            </div>
        </div>
    </div>
    ';
    return $startnext_partner_logo_markup;
}
add_shortcode('startnext_partner_logo', 'startnext_partner_logo_shortcode');