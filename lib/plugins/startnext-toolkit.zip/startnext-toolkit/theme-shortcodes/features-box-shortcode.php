<?php
function startnext_features_box_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'custom_class'  => '',
        'count'         => '',
        'columns'       => 4,
        'style'         => '',
        'args'         => '',
    ), $atts) );

    if ($columns == 1) {
        $column = 'col-lg-12 col-md-6';
    }elseif ($columns == 2) {
        $column = 'col-lg-6 col-md-6';
    }elseif ($columns == 3) {
        $column = 'col-lg-4 col-md-6';
    }elseif ($columns == 4) {
        $column = 'col-lg-3 col-md-6';
    }

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $domain = 'startnext-toolkit';

    if ((class_exists( 'CMB2_Bootstrap_260', true ))){
        $boxes = get_post_meta(get_the_ID(),"_startnext_nav_color",true);
        if($boxes == true){
            $boxes_class = 'boxes-area hosting-boxes-area';
        }else{
            $boxes_class = '';
        }
    }

    $startnext_features_box_markup ='';
    if($style == 1){
    $startnext_features_box_markup .='
    <div class="boxes-area '.esc_attr__($boxes_class, $domain).'">
        <div class="container">
            <div class="row">';
                if ($args != '') {
                    $features_array = new WP_Query( array('posts_per_page' => $count, 'post_type' => 'feature', 'tax_query' => array( array( 'taxonomy' => 'feature_cat', 'terms' => $args, ) ) ) );
                }else{
                    $features_array = new WP_Query( array('posts_per_page' => $count, 'post_type' => 'feature',) );
                }
            
                while($features_array->have_posts()): $features_array->the_post();
                $id = get_the_ID();
                $icon = get_post_meta( get_the_ID(), 'startnext_feature_iconselect', true );
                $iconcolor = get_post_meta( get_the_ID(), 'startnext_feature_iconcolor', true );
                $iconbg = get_post_meta( get_the_ID(), 'startnext_feature_iconbg', true );
                $startnext_features_box_markup .='
            
                <div class="'.esc_attr__($column, $domain).'">
                    <div class="single-box'.esc_attr__($custom_class, $domain).'">
                        <div class="icon" style="background: '.esc_attr__($iconbg,'startnext-toolkit') .';" >';
                        if (empty($icon)) {
                            $startnext_features_box_markup .='
                            <i class="fa fa-cog" style="color: '.esc_attr__($iconcolor,'startnext-toolkit').';" ></i>';
                        }else{
                            $startnext_features_box_markup .='
                            <i class="'.esc_attr__($icon,'startnext-toolkit') .'" style="color: '.esc_attr__($iconcolor,'startnext-toolkit').';" ></i>';
                        }
                        $startnext_features_box_markup .='
                        </div>
                        <h3><a href="'.get_the_permalink($id).'">'.get_the_title($id) .'</a></h3>
                        <p>'.get_the_excerpt($id) .'</p>
                    </div>
                </div>';
                endwhile;
                $startnext_features_box_markup .='
            </div>
        </div>
    </div>';
    }elseif($style == 2){
        $startnext_features_box_markup .='
        <div class="container">
            <div class="row">';
            $features_array = new WP_Query(
                array('posts_per_page' => $count, 'post_type' => 'feature'));
                while($features_array->have_posts()): $features_array->the_post();
                $id = get_the_ID();
                $icon = get_post_meta( get_the_ID(), 'startnext_feature_iconselect', true );
                $iconcolor = get_post_meta( get_the_ID(), 'startnext_feature_iconcolor', true );
                $iconbg = get_post_meta( get_the_ID(), 'startnext_feature_iconbg', true );
                $startnext_features_box_markup .='
            
                <div class="'.esc_attr__($column, $domain).'">
                    <div class="single-features'.esc_attr__($custom_class, $domain).'">
                        <div class="icon" style="background: '.esc_attr__($iconbg,'startnext-toolkit') .';" >';
                        if (empty($icon)) {
                            $startnext_features_box_markup .='
                            <i class="fa fa-cog" style="color: '.esc_attr__($iconcolor,'startnext-toolkit').';" ></i>';
                        }else{
                            $startnext_features_box_markup .='
                            <i class="'.esc_attr__($icon,'startnext-toolkit') .'" style="color: '.esc_attr__($iconcolor,'startnext-toolkit').';" ></i>';
                        }
                        $startnext_features_box_markup .='
                        </div>
                        <h3><a href="'.get_the_permalink($id).'">'.get_the_title($id) .'</a></h3>
                        <p>'.get_the_excerpt($id) .'</p>
                    </div>
                </div>';
                endwhile;
                $startnext_features_box_markup .='
            </div>
        </div>';
    }else{
    $startnext_features_box_markup .='
        <div class="container">
            <div class="row">';
            $features_array = new WP_Query(
                array('posts_per_page' => $count, 'post_type' => 'feature'));
                while($features_array->have_posts()): $features_array->the_post();
                $id = get_the_ID();
                $icon = get_post_meta( get_the_ID(), 'startnext_feature_iconselect', true );
                $iconcolor = get_post_meta( get_the_ID(), 'startnext_feature_iconcolor', true );
                $iconbg = get_post_meta( get_the_ID(), 'startnext_feature_iconbg', true );
                $startnext_features_box_markup .='
            
                <div class="'.esc_attr__($column, $domain).'">
                    <div class="single-hosting-features'.esc_attr__($custom_class, $domain).'">
                        <div class="icon" style="background: '.esc_attr__($iconbg,'startnext-toolkit') .';" >';
                        if (empty($icon)) {
                            $startnext_features_box_markup .='
                            <i class="fa fa-cog" style="color: '.esc_attr__($iconcolor,'startnext-toolkit').';" ></i>';
                        }else{
                            $startnext_features_box_markup .='
                            <i class="'.esc_attr__($icon,'startnext-toolkit') .'" style="color: '.esc_attr__($iconcolor,'startnext-toolkit').';" ></i>';
                        }
                        $startnext_features_box_markup .='
                        </div>
                        <h3><a href="'.get_the_permalink($id).'">'.get_the_title($id) .'</a></h3>
                        <p>'.get_the_excerpt($id) .'</p>
                    </div>
                </div>';
                endwhile;
                $startnext_features_box_markup .='
            </div>
        </div>';
    }
    return $startnext_features_box_markup;
}
add_shortcode('startnext_features_box', 'startnext_features_box_shortcode');
