<?php
function startnext_why_choose_us_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'img'           => '',
        'title'         => '',
        'description'   => '',
        'custom_class'  => '',
    ), $atts) );
    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $domain = 'startnext-toolkit';
    $items = vc_param_group_parse_atts($atts['group_card']); 
    $side_image = wp_get_attachment_image_src($img, 'large');

    $startnext_why_choose_us_markup ='';

    $startnext_why_choose_us_markup .='
    <div class="why-choose-us ptb-80 '.esc_attr__($custom_class, $domain).'">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-12">
                    <div class="section-title">';
                    if(!$title == '') { $startnext_why_choose_us_markup .='
                        <h2>'.esc_html__($title, $domain).'</h2>
                        <div class="bar"></div>';
                    } $startnext_why_choose_us_markup .='
                        <p>'.esc_html__($description, $domain).'</p>
                    </div>';

                    if ($side_image[0] != '') { 
                        $startnext_why_choose_us_markup .='
                        <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('hero-img','startnext-toolkit').'" class="wow fadeInDown bannerrightimg" >';
                    }else{ $startnext_why_choose_us_markup .='
                            
                        <div class="why-choose-us-image">
                            <img src="'. get_template_directory_uri() .'/assets/img/why-choose-us-image/man-stand.png" class="wow fadeInLeft" alt="'.esc_attr__('man','startnext-toolkit').'">
                            <img src="'. get_template_directory_uri() .'/assets/img/why-choose-us-image/database.png" class="wow fadeInRight" alt="'.esc_attr__('man','startnext-toolkit').'">
                            <img src="'. get_template_directory_uri() .'/assets/img/services-left-image/cercle-shape.png" class="rotateme" alt="'.esc_attr__('man','startnext-toolkit').'">
                            <img src="'. get_template_directory_uri() .'/assets/img/why-choose-us-image/main-static.png" class="main-pic wow fadeInUp" alt="'.esc_attr__('man','startnext-toolkit').'">
                        </div>';
                    }
                    $startnext_why_choose_us_markup .='
                </div>

                <div class="col-lg-6 col-md-12">
                    <div class="row">';
                        foreach($items as $item){
                            if (!empty($item)) {
                                if(isset($item['icon']) &&  isset($item['title']) &&  isset($item['description'])):
                                    $startnext_why_choose_us_markup .='
                                    <div class="col-lg-6 col-md-6">
                                        <div class="single-why-choose-us">
                                            <div class="icon">
                                                <i class="'.esc_attr__($item['icon'], $domain).'"></i>
                                            </div>
                                            <h3>'.esc_html__($item['title'], $domain).'</h3>
                                            <p>'.esc_html__($item['description'], $domain).'</p>
                                        </div>
                                    </div>';
                                endif;
                            }
                        }
                        $startnext_why_choose_us_markup .='
                    </div>
                </div>
            </div>
        </div>
    </div>';
    return $startnext_why_choose_us_markup;
}
add_shortcode('startnext_why_choose_us', 'startnext_why_choose_us_shortcode');