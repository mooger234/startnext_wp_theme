<?php
function startnext_search_domain_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         	=> '',
        'placeholder_text'  => '',
        'search_button'  	=> '',
        'custom_class'  	=> '',
    ), $atts) );

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $items = vc_param_group_parse_atts($atts['group_domain']); 

    $domain = 'startnext-toolkit';

    $startnext_search_domain_markup ='
    <div class="domain-search-area ptb-80 '.esc_attr__($custom_class, $domain).'">
        <div class="container">
            <div class="domain-search-content">
                <h2>'.esc_html__($title, $domain).'</h2>
					<form>
						<input type="text" class="form-control" name="domain-search" id="domain-search" placeholder="'.esc_attr_x($placeholder_text, $domain).'">

						<div class="domain-select">';
							if(!$items == ''){ $startnext_search_domain_markup .='
							<select class="form-control">';
								foreach($items as $item){ 
									if(isset($item['type']) ):
										$startnext_search_domain_markup .='  
										<option>'.esc_html__($item['type'],'startnext-toolkit') .'</option>';
									endif;
								} 
								$startnext_search_domain_markup .='
							</select>';
							}
							$startnext_search_domain_markup .='
						</div>';
						if(!$search_button == ''){
							$startnext_search_domain_markup .='
							<button type="submit">'.esc_html__($search_button, $domain).'</button>';
						} $startnext_search_domain_markup .='
					</form>';
                if(!$items == ''){ $startnext_search_domain_markup .='
                <ul class="domain-price">';
                    foreach($items as $item){ 
                        if(isset($item['type']) &&  isset($item['price']) ):
                            $startnext_search_domain_markup .='  
                            <li>'.esc_html__($item['type'],'startnext-toolkit') .'<br>'.esc_html__($item['price'],'startnext-toolkit') .'</li>';
                        endif;
                    } 
                    $startnext_search_domain_markup .='
                </ul>';
                }
                $startnext_search_domain_markup .='
            </div>
        </div>
    </div>';

    return $startnext_search_domain_markup;
    
}
add_shortcode('startnext_search_domain', 'startnext_search_domain_shortcode');