<?php
vc_map( 
    array(
        "name" => esc_html__( "Design and Development", 'startnext-toolkit' ),
        "base" => "startnext_design_and_development",
        "class" => "",
        "category" => esc_html__( "StartNext", 'startnext-toolkit'),
        "icon" => get_template_directory_uri() . "/assets/img/startnext-icon.png",
        "params" => array(
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Section Title", 'startnext-toolkit' ),
                "param_name" => "title",
            ),
            array(
                "type" => "textarea",
                "heading" => esc_html__( "Section Description", 'startnext-toolkit' ),
                "param_name" => "description",
            ),

            array(
                'type' => 'param_group',
                'param_name' => 'group_items', 
                'params' => array(
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Item Name", 'startnext-toolkit' ),
                        "param_name" => "item",
                    ),
                    array(
                        "type" => "iconpicker",
                        "heading" => esc_html__( "Item Icon", 'startnext-toolkit' ),
                        "param_name" => "icon",
                    ),
                )
            ),
            array(
                "type" => "attach_image",
                "heading" => esc_html__( "Right Side Image", 'startnext-toolkit' ),
                "param_name" => "img",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Add Your Extra Class Name", 'startnext-toolkit' ),
                "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", 'startnext-toolkit' ),
                "param_name" => "custom_class",
            ),
        )
    )   
);