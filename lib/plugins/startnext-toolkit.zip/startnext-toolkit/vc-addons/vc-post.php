<?php
vc_map( 
    array(
        "name" => esc_html__( "Blog Post", 'startnext-toolkit' ),
        "base" => "startnext_post",
        "class" => "",
        "category" => esc_html__( "StartNext", 'startnext-toolkit'),
        "icon" => get_template_directory_uri() . "/assets/img/startnext-icon.png",
        "params" => array(
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Count", 'startnext-toolkit' ),
                "param_name" => "postcount",
                "description" => esc_html__( "If you want to see all post type -1", 'startnext-toolkit' )
            ),
            array(
                "type"          => "dropdown",
                "heading"       => esc_html__( "Choose Columns ", 'startnext-toolkit' ),
                "param_name"    => "columns",
                'admin_label'   => true,
                    'value'       => array(
                    '2'   => 2,
                    '3'   => 3,
                    '4'   => 4
                ),
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Add Your Extra Class Name", 'startnext-toolkit' ),
                "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", 'startnext-toolkit' ),
                "param_name" => "custom_class",
            ),
        )
    )   
);