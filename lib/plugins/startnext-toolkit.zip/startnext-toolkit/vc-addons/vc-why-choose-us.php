<?php
vc_map( 
    array(
        "name" => esc_html__( "Why Choose Us", 'startnext-toolkit' ),
        "base" => "startnext_why_choose_us",
        "class" => "",
        "category" => esc_html__( "StartNext", 'startnext-toolkit'),
        "icon" => get_template_directory_uri() . "/assets/img/startnext-icon.png",
        "params" => array(
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Section Title", 'startnext-toolkit' ),
                "param_name" => "title",
            ),
            array(
                "type" => "textarea",
                "heading" => esc_html__( "Section Description", 'startnext-toolkit' ),
                "param_name" => "description",
            ),
            array(
                "type" => "attach_image",
                "heading" => esc_html__( "Section Image", 'startnext-toolkit' ),
                "param_name" => "img",
            ),
            array(
                'type' => 'param_group',
                'param_name' => 'group_card', 
                'heading' => esc_html__( 'Add Card', 'startnext-toolkit' ),
                'params' => array(
                    array(
                        "type" => "iconpicker",
                        "heading" => esc_html__( "Icon", 'startnext-toolkit' ),
                        "param_name" => "icon",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "title", 'startnext-toolkit' ),
                        "param_name" => "title",
                    ),
                    array(
                        "type" => "textarea",
                        "heading" => esc_html__( "Description", 'startnext-toolkit' ),
                        "param_name" => "description",
                    ),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Add Your Extra Class Name", 'startnext-toolkit' ),
                "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", 'startnext-toolkit' ),
                "param_name" => "custom_class",
            ),
            
        )
    )   
);