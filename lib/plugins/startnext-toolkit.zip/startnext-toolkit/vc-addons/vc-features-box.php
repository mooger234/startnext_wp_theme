<?php
vc_map( 
    array(
        "name" => esc_html__( "Features", 'startnext-toolkit' ),
        "base" => "startnext_features_box",
        "class" => "",
        "category" => esc_html__( "StartNext", 'startnext-toolkit'),
        "icon" => get_template_directory_uri() . "/assets/img/startnext-icon.png",
        "params" => array(
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Count", 'startnext-toolkit' ),
                "param_name" => "count",
                "description" => esc_html__( "If you want to see all post type -1", 'startnext-toolkit' )
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Choose Category", 'startnext-toolkit' ),
                "param_name" => "args",
                "value" => startnext_toolkit_get_page_feature_cat(),
            ),
            array(
                "type"          => "dropdown",
                "heading"       => esc_html__( "Choose Style", 'startnext-toolkit' ),
                "param_name"    => "style",
                'admin_label'   => true,
                'value'     => array(
                    'Top Icon'      => 1,
                    'Left Icon'     => 2,
                    'Top Center'    => 3,
                ),
            ),
            array(
                "type"          => "dropdown",
                "heading"       => esc_html__( "Choose Columns ", 'startnext-toolkit' ),
                "param_name"    => "columns",
                'admin_label'   => true,
                    'value'       => array(
                    '1'   => 1,
                    '2'   => 2,
                    '3'   => 3,
                    '4'   => 4
                ),
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Add Your Extra Class Name", 'startnext-toolkit' ),
                "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", 'startnext-toolkit' ),
                "param_name" => "custom_class",
            ),  
        )
    )   
);