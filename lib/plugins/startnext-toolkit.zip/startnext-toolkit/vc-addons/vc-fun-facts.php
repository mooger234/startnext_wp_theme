<?php
vc_map( 
    array(
        "name" => esc_html__( "Users Expectation (Fun Facts)", 'startnext-toolkit' ),
        "base" => "startnext_user_expectation",
        "class" => "",
        "category" => esc_html__( "StartNext", 'startnext-toolkit'),
        "icon" => get_template_directory_uri() . "/assets/img/startnext-icon.png",
        "params" => array(
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Title", 'startnext-toolkit' ),
                "param_name" => "title",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Counter Number", 'startnext-toolkit' ),
                "param_name" => "number",
            ),  
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Counter Symble", 'startnext-toolkit' ),
                "param_name" => "symble",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Add Your Extra Class Name", 'startnext-toolkit' ),
                "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", 'startnext-toolkit' ),
                "param_name" => "custom_class",
            ),
        )
    )   
);